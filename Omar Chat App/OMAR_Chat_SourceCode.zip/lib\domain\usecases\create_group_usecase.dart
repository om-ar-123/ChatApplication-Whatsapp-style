import '../../data/repositories/group_repository.dart';

class CreateGroupUseCase {
  CreateGroupUseCase({GroupRepository? groupRepository})
      : _groupRepository = groupRepository ?? GroupRepository();

  final GroupRepository _groupRepository;

  Future<int> execute(String title, List<int> memberIds) {
    if (memberIds.length < 2) {
      throw Exception('Select at least 2 members for a group');
    }
    return _groupRepository.createGroup(title, memberIds);
  }
}
