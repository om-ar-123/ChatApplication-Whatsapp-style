import 'in_memory_store.dart';

/// Simulated database facade — delegates to [InMemoryStore] (no SQLite).
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  final InMemoryStore _store = InMemoryStore.instance;

  InMemoryStore get store => _store;

  Future<void> initialize() => _store.initialize();
}
