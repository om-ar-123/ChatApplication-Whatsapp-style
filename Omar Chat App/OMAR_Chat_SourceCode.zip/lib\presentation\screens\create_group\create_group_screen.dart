import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/app_routes.dart';
import '../../../core/constants/app_strings.dart';
import '../../state/group_cubit.dart';
import '../../widgets/profile_avatar.dart';

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _nameController = TextEditingController();
  final _broadcastController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<GroupCubit>().resetForNewGroup();
    context.read<GroupCubit>().loadUsers();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _broadcastController.dispose();
    super.dispose();
  }

  Future<void> _createGroup() async {
    final name = _nameController.text.trim();
    if (name.isEmpty || context.read<GroupCubit>().state.selectedUserIds.isEmpty) return;

    final chatId = await context.read<GroupCubit>().createGroup(groupName: name);
    if (!mounted || chatId == null) return;

    final title = context.read<GroupCubit>().state.groupName;
    context.read<GroupCubit>().clearCreatedGroup();
    Navigator.pop(context, {
      'chatId': chatId,
      'title': title,
      'isGroup': true,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.createGroup)),
      body: BlocConsumer<GroupCubit, GroupState>(
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(state.error!)));
          }
        },
        builder: (context, state) {
          final canCreate = state.selectedUserIds.isNotEmpty && _nameController.text.trim().isNotEmpty;

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Group name'),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              if (state.selectedUserIds.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '${state.selectedUserIds.length} member${state.selectedUserIds.length == 1 ? '' : 's'} selected',
                      style: TextStyle(color: Colors.grey.shade700),
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: TextField(
                  controller: _broadcastController,
                  decoration: const InputDecoration(
                    labelText: 'Message selected users (optional)',
                  ),
                  onChanged: context.read<GroupCubit>().setBroadcastMessage,
                ),
              ),
              if (state.broadcastMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: ElevatedButton(
                    onPressed: state.selectedUserIds.isEmpty
                        ? null
                        : () => context.read<GroupCubit>().broadcastToSelected(),
                    child: const Text('Send to selected users'),
                  ),
                ),
              Expanded(
                child: state.isLoading && state.allUsers.isEmpty
                    ? const Center(child: CircularProgressIndicator())
                    : ListView.builder(
                        itemCount: state.allUsers.length,
                        itemBuilder: (context, index) {
                          final user = state.allUsers[index];
                          final selected = state.selectedUserIds.contains(user.id);
                          return CheckboxListTile(
                            value: selected,
                            onChanged: (_) {
                              context.read<GroupCubit>().toggleUser(user.id);
                              setState(() {});
                            },
                            secondary: ProfileAvatar(name: user.name, imagePath: user.avatarPath),
                            title: Text(user.name),
                            subtitle: Text(user.jobTitle ?? user.email ?? ''),
                          );
                        },
                      ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: !canCreate || state.isLoading ? null : _createGroup,
                    child: state.isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Create Group'),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
