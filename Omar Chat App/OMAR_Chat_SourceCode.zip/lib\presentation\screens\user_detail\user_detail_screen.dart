import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/app_routes.dart';
import '../../../core/constants/db_constants.dart';
import '../../../domain/usecases/create_chat_usecase.dart';
import '../../state/profile_cubit.dart';
import '../../widgets/profile_avatar.dart';
import '../call/call_screen.dart';
import '../../../domain/entities/call_session.dart';

class UserDetailScreen extends StatelessWidget {
  const UserDetailScreen({super.key, required this.userId});

  final int userId;

  static final _createChatUseCase = CreateChatUseCase();

  @override
  Widget build(BuildContext context) {
    if (userId <= 0) {
      return Scaffold(
        appBar: AppBar(title: const Text('User Info')),
        body: const Center(child: Text('Invalid user')),
      );
    }

    return BlocProvider(
      create: (_) => ProfileCubit(userId: userId)..load(),
      child: Scaffold(
        appBar: AppBar(title: const Text('User Info')),
        body: BlocBuilder<ProfileCubit, ProfileState>(
          builder: (context, state) {
            if (state.isLoading) {
              return const Center(child: CircularProgressIndicator());
            }
            final user = state.user;
            if (user == null) return const Center(child: Text('User not found'));

            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  ProfileAvatar(
                    name: user.name,
                    imagePath: user.avatarPath,
                    radius: 50,
                    onTap: () {},
                  ),
                  const SizedBox(height: 16),
                  Text(user.name, style: Theme.of(context).textTheme.headlineSmall),
                  if (user.email != null) ...[
                    const SizedBox(height: 8),
                    Text(user.email!, style: TextStyle(color: Colors.grey.shade700)),
                  ],
                  if (user.jobTitle != null) ...[
                    const SizedBox(height: 8),
                    Text(user.jobTitle!, style: const TextStyle(fontWeight: FontWeight.w500)),
                  ],
                  if (user.bio != null) ...[
                    const SizedBox(height: 16),
                    Text(user.bio!, textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.circle,
                        size: 12,
                        color: user.isOnline ? Colors.green : Colors.grey,
                      ),
                      const SizedBox(width: 4),
                      Text(user.isOnline ? 'Online' : 'Offline'),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _ContactAction(
                        icon: Icons.call,
                        label: 'Call',
                        onTap: () => openSimulatedCall(
                          context,
                          contactName: user.name,
                          type: CallType.voice,
                          contactUserId: user.id,
                        ),
                      ),
                      const SizedBox(width: 32),
                      _ContactAction(
                        icon: Icons.videocam,
                        label: 'Video',
                        onTap: () => openSimulatedCall(
                          context,
                          contactName: user.name,
                          type: CallType.video,
                          contactUserId: user.id,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () async {
                      final chatId = await _createChatUseCase.execute(
                        DbConstants.currentUserId,
                        user.id,
                      );
                      if (context.mounted) {
                        Navigator.pushNamed(
                          context,
                          AppRoutes.chatDetail,
                          arguments: {
                            'chatId': chatId,
                            'title': user.name,
                            'otherUserId': user.id,
                          },
                        );
                      }
                    },
                    child: const Text('Message'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ContactAction extends StatelessWidget {
  const _ContactAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: const Color(0xFF008069),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(label),
          ],
        ),
      ),
    );
  }
}
